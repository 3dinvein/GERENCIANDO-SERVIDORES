#!/bin/bash

#########################################################
#   MENU DO GERENCIADOR DO FIREWALL - MENU PRINCIPAL    #
#########################################################

iptables-restore /etc/firewall

(dialog --title "GERENCIADOR FIREWALL" --yesno "\n\nVOCÊ DESEJA ADICIONAR MAIS REGRAS?" 10 50 --stdout)

status=$?

case $status in
0)
/etc/GerenciadorFirewall/menu/menuTipoDeRegraFirewall.sh;;
1)
clear
exit;;
*)
echo "Saindo do programa"
clear
exit;;
esac
