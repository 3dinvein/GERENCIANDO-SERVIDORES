#!/bin/bash

#################################################
#  APLICANDO REGRA BLOQUEAR NO AUDITÓRIO 309    #
#################################################

block=`/etc/GerenciadorFirewall/block-iptables/auditorios/auditorio309/block_forAuditorio309.sh`
status=$?
dialog --title "REGRAS DE BLOQUEIO" --msgbox "\n\nAUDITÓRIO 309 BLOQUEADO" 10 35

case $status in 
0)
clear
exit;;
esac
