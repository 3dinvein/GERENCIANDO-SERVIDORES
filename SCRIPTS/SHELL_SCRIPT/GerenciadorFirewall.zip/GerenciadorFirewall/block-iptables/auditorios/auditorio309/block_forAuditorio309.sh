#!/bin/bash

##########################################################
#  CRIA REGRA IPTABLES PARA BLOQUEAR NO AUDITÓRIO 309    #
##########################################################
 
  iptables -A INPUT -s auditorio -p tcp -m tcp -j DROP
  iptables -A INPUT -d auditorio -p tcp -m tcp -j DROP
  iptables -A FORWARD -s auditorio -p tcp -m tcp -j DROP
  iptables -A FORWARD -d auditorio -p tcp -m tcp -j DROP
  iptables -A OUTPUT -s auditorio -p tcp -m tcp -j DROP
  iptables -A OUTPUT -d auditorio -p tcp -m tcp -j DROP
