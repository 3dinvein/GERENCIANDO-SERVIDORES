#!/bin/bash

##########################################################
#  CRIA REGRA IPTABLES PARA BLOQUEAR NO AUDITÓRIO 409    #
##########################################################
 
  iptables -A INPUT -s sala409-01 -p tcp -m tcp -j DROP
  iptables -A INPUT -d sala409-01 -p tcp -m tcp -j DROP
  iptables -A FORWARD -s sala409-01 -p tcp -m tcp -j DROP
  iptables -A FORWARD -d sala409-01 -p tcp -m tcp -j DROP
  iptables -A OUTPUT -s sala409-01 -p tcp -m tcp -j DROP
  iptables -A OUTPUT -d sala409-01 -p tcp -m tcp -j DROP
