#!/bin/bash

#################################################
#  APLICANDO REGRA BLOQUEAR NO AUDITÓRIO 409  #
#################################################

block=`/etc/GerenciadorFirewall/block-iptables/auditorios/auditorio409/block_forAuditorio409.sh`
status=$?
dialog --title "REGRAS DE BLOQUEIO" --msgbox "\n\nAUDITÓRIO 409 BLOQUEADO" 10 35

case $status in 
0)
clear
exit;;
esac
