#!/bin/bash

#################################################
#  APLICANDO REGRA BLOQUEAR A SALA DE AULA 122  #
#################################################

block=`/etc/GerenciadorFirewall/block-iptables/salaDeAulas/sala122/block_forSalaDeAula122.sh`
status=$?
dialog --title "REGRAS DE BLOQUEIO" --msgbox "\n\nSALA DE AULA 122 BLOQUEADO" 10 35

case $status in 
0)
clear
exit;;
esac
