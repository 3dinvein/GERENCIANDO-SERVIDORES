#!/bin/bash

#################################################
#  APLICANDO REGRA BLOQUEAR A SALA DE AULA 123  #
#################################################

block=`/etc/GerenciadorFirewall/block-iptables/salaDeAulas/sala123/block_forSalaDeAula123.sh`
status=$?
dialog --title "REGRAS DE BLOQUEIO" --msgbox "\n\nSALA DE AULA 123 BLOQUEADO" 10 35

case $status in 
0)
clear
exit;;
esac
