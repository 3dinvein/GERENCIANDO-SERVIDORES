#!/bin/bash

###########################################################
#  CRIA REGRA IPTABLES PARA BLOQUEAR NO SALA DE AULA 123  #
###########################################################


  iptables -A INPUT -s sala123-01 -p tcp -m tcp -j DROP
  iptables -A INPUT -d sala123-01 -p tcp -m tcp -j DROP
  iptables -A FORWARD -s sala123-01 -p tcp -m tcp -j DROP
  iptables -A FORWARD -d sala123-01 -p tcp -m tcp -j DROP
  iptables -A OUTPUT -s sala123-01 -p tcp -m tcp -j DROP
  iptables -A OUTPUT -d sala123-01 -p tcp -m tcp -j DROP
