#!/bin/bash

#################################################
#  APLICANDO REGRA BLOQUEAR A SALA DE AULA 308  #
#################################################

block=`/etc/GerenciadorFirewall/block-iptables/salaDeAulas/sala308/block_forSalaDeAula308.sh`
status=$?
dialog --title "REGRAS DE BLOQUEIO" --msgbox "\n\nSALA DE AULA 308 BLOQUEADO" 10 35

case $status in 
0)
clear
exit;;
esac
