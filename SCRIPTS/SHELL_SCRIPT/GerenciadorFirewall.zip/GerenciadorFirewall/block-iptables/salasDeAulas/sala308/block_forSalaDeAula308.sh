#!/bin/bash

###########################################################
#  CRIA REGRA IPTABLES PARA BLOQUEAR NO SALA DE AULA 308  #
###########################################################


  iptables -A INPUT -s sala308-01 -p tcp -m tcp -j DROP
  iptables -A INPUT -d sala308-01 -p tcp -m tcp -j DROP
  iptables -A FORWARD -s sala308-01 -p tcp -m tcp -j DROP
  iptables -A FORWARD -d sala308-01 -p tcp -m tcp -j DROP
  iptables -A OUTPUT -s sala308-01 -p tcp -m tcp -j DROP
  iptables -A OUTPUT -d sala308-01 -p tcp -m tcp -j DROP
