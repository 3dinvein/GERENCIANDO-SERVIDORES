#!/bin/bash

#################################################
#  APLICANDO REGRA BLOQUEAR A SALA DE AULA 316  #
#################################################

block=`/etc/GerenciadorFirewall/block-iptables/salaDeAulas/sala316/block_forSalaDeAula316.sh`
status=$?
dialog --title "REGRAS DE BLOQUEIO" --msgbox "\n\nSALA DE AULA 316 BLOQUEADO" 10 35

case $status in 
0)
clear
exit;;
esac
