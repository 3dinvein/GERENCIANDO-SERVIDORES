#!/bin/bash

###########################################################
#  CRIA REGRA IPTABLES PARA BLOQUEAR NO SALA DE AULA 316  #
###########################################################


  iptables -A INPUT -s sala316-01 -p tcp -m tcp -j DROP
  iptables -A INPUT -d sala316-01 -p tcp -m tcp -j DROP
  iptables -A FORWARD -s sala316-01 -p tcp -m tcp -j DROP
  iptables -A FORWARD -d sala316-01 -p tcp -m tcp -j DROP
  iptables -A OUTPUT -s sala316-01 -p tcp -m tcp -j DROP
  iptables -A OUTPUT -d sala316-01 -p tcp -m tcp -j DROP
