#!/bin/bash

###########################################################
#  CRIA REGRA IPTABLES PARA BLOQUEAR NO SALA DE AULA 124  #
###########################################################


  iptables -A INPUT -s sala124-01 -p tcp -m tcp -j DROP
  iptables -A INPUT -d sala124-01 -p tcp -m tcp -j DROP
  iptables -A FORWARD -s sala124-01 -p tcp -m tcp -j DROP
  iptables -A FORWARD -d sala124-01 -p tcp -m tcp -j DROP
  iptables -A OUTPUT -s sala124-01 -p tcp -m tcp -j DROP
  iptables -A OUTPUT -d sala124-01 -p tcp -m tcp -j DROP
