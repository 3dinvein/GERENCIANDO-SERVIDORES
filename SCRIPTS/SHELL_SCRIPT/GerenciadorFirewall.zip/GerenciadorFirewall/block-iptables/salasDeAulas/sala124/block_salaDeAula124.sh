#!/bin/bash

#################################################
#  APLICANDO REGRA BLOQUEAR A SALA DE AULA 124  #
#################################################

block=`/etc/GerenciadorFirewall/block-iptables/salaDeAulas/sala124/block_forSalaDeAula124.sh`
status=$?
dialog --title "REGRAS DE BLOQUEIO" --msgbox "\n\nSALA DE AULA 124 BLOQUEADO" 10 35

case $status in 
0)
clear
exit;;
esac
