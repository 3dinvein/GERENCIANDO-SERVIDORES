#!/bin/bash

##################################################
#  APLICANDO REGRA BLOQUEAR A SALA DE AULA 305A  #
##################################################

block=`/etc/GerenciadorFirewall/block-iptables/salaDeAulas/sala305A/block_forSalaDeAula305A.sh`
status=$?
dialog --title "REGRAS DE BLOQUEIO" --msgbox "\n\nSALA DE AULA 305A BLOQUEADO" 10 35

case $status in 
0)
clear
exit;;
esac
