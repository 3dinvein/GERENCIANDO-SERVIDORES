#!/bin/bash

##################################################
#  APLICANDO REGRA BLOQUEAR A SALA DE AULA 314A  #
##################################################

block=`/etc/GerenciadorFirewall/block-iptables/salaDeAulas/sala314A/block_forSalaDeAula314A.sh`
status=$?
dialog --title "REGRAS DE BLOQUEIO" --msgbox "\n\nSALA DE AULA 314A BLOQUEADO" 10 35

case $status in 
0)
clear
exit;;
esac
