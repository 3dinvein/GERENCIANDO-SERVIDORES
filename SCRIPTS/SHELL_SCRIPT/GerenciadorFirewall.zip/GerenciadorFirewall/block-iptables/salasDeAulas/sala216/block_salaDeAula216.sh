#!/bin/bash

#################################################
#  APLICANDO REGRA BLOQUEAR A SALA DE AULA 216  #
#################################################

block=`/etc/GerenciadorFirewall/block-iptables/salaDeAulas/sala216/block_forSalaDeAula216.sh`
status=$?
dialog --title "REGRAS DE BLOQUEIO" --msgbox "\n\nSALA DE AULA 216 BLOQUEADO" 10 35

case $status in 
0)
clear
exit;;
esac
