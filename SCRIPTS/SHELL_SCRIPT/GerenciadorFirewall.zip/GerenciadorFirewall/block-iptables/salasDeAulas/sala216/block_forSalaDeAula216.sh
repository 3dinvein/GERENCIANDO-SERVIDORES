#!/bin/bash

###########################################################
#  CRIA REGRA IPTABLES PARA BLOQUEAR NO SALA DE AULA 216  #
###########################################################


  iptables -A INPUT -s sala216-01 -p tcp -m tcp -j DROP
  iptables -A INPUT -d sala216-01 -p tcp -m tcp -j DROP
  iptables -A FORWARD -s sala216-01 -p tcp -m tcp -j DROP
  iptables -A FORWARD -d sala216-01 -p tcp -m tcp -j DROP
  iptables -A OUTPUT -s sala216-01 -p tcp -m tcp -j DROP
  iptables -A OUTPUT -d sala216-01 -p tcp -m tcp -j DROP
