#!/bin/bash

#################################################
#  APLICANDO REGRA BLOQUEAR A SALA DE AULA 314B  #
#################################################

block=`/etc/GerenciadorFirewall/block-iptables/salaDeAulas/sala314B/block_forSalaDeAula314B.sh`
status=$?
dialog --title "REGRAS DE BLOQUEIO" --msgbox "\n\nSALA DE AULA 314B BLOQUEADO" 10 35

case $status in 
0)
clear
exit;;
esac
