#!/bin/bash

###########################################################
#  CRIA REGRA IPTABLES PARA BLOQUEAR NO SALA DE AULA 314B  #
###########################################################


  iptables -A INPUT -s sala314B-01 -p tcp -m tcp -j DROP
  iptables -A INPUT -d sala314B-01 -p tcp -m tcp -j DROP
  iptables -A FORWARD -s sala314B-01 -p tcp -m tcp -j DROP
  iptables -A FORWARD -d sala314B-01 -p tcp -m tcp -j DROP
  iptables -A OUTPUT -s sala314B-01 -p tcp -m tcp -j DROP
  iptables -A OUTPUT -d sala314B-01 -p tcp -m tcp -j DROP
