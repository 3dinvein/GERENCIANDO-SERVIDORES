#!/bin/bash

#################################################
#  APLICANDO REGRA BLOQUEAR A SALA DE AULA 215  #
#################################################

block=`/etc/GerenciadorFirewall/block-iptables/salaDeAulas/sala215/block_forSalaDeAula215.sh`
status=$?
dialog --title "REGRAS DE BLOQUEIO" --msgbox "\n\nSALA DE AULA 215 BLOQUEADO" 10 35

case $status in 
0)
clear
exit;;
esac
