#!/bin/bash

###########################################################
#  CRIA REGRA IPTABLES PARA BLOQUEAR NO SALA DE AULA 215A  #
###########################################################


  iptables -A INPUT -s sala215A-01 -p tcp -m tcp -j DROP
  iptables -A INPUT -d sala215A-01 -p tcp -m tcp -j DROP
  iptables -A FORWARD -s sala215A-01 -p tcp -m tcp -j DROP
  iptables -A FORWARD -d sala215A-01 -p tcp -m tcp -j DROP
  iptables -A OUTPUT -s sala215A-01 -p tcp -m tcp -j DROP
  iptables -A OUTPUT -d sala215A-01 -p tcp -m tcp -j DROP
