#!/bin/bash

###########################################################
#  CRIA REGRA IPTABLES PARA BLOQUEAR NO SALA DE AULA 305B  #
###########################################################


  iptables -A INPUT -s sala305B-01 -p tcp -m tcp -j DROP
  iptables -A INPUT -d sala305B-01 -p tcp -m tcp -j DROP
  iptables -A FORWARD -s sala305B-01 -p tcp -m tcp -j DROP
  iptables -A FORWARD -d sala305B-01 -p tcp -m tcp -j DROP
  iptables -A OUTPUT -s sala305B-01 -p tcp -m tcp -j DROP
  iptables -A OUTPUT -d sala305B-01 -p tcp -m tcp -j DROP
