#!/bin/bash

##################################################
#  APLICANDO REGRA BLOQUEAR A SALA DE AULA 305B  #
##################################################

block=`/etc/GerenciadorFirewall/block-iptables/salaDeAulas/sala305B/block_forSalaDeAula305B.sh`
status=$?
dialog --title "REGRAS DE BLOQUEIO" --msgbox "\n\nSALA DE AULA 305B BLOQUEADO" 10 35

case $status in 
0)
clear
exit;;
esac
