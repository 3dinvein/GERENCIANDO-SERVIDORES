#!/bin/bash

#################################################
#  APLICANDO REGRA BLOQUEAR NO LABORATÓRIO 405  #
#################################################

block=`/etc/GerenciadorFirewall/block-iptables/laboratorios/lab405/block_forLaboratorio405.sh`
status=$?
dialog --title "REGRAS DE BLOQUEIO" --msgbox "\n\nLABORATÓRIO 405 BLOQUEADO MENOS O PC DO PROFESSOR" 10 35

case $status in 
0)
clear
exit;;
esac
