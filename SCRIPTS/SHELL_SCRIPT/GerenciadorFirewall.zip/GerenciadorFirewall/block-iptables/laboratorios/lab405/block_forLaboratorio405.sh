#!/bin/bash

##########################################################
#  CRIA REGRA IPTABLES PARA BLOQUEAR NO LABORATÓRIO 405  #
##########################################################

for((i = 1; i <= 30; i++))
do
if [ $i -le 9 ]
 then  
  iptables -A INPUT -s sala405-0$i -p tcp -m tcp -j DROP
  iptables -A INPUT -d sala405-0$i -p tcp -m tcp -j DROP
  iptables -A FORWARD -s sala405-0$i -p tcp -m tcp -j DROP
  iptables -A FORWARD -d sala405-0$i -p tcp -m tcp -j DROP
  iptables -A OUTPUT -s sala405-0$i -p tcp -m tcp -j DROP
  iptables -A OUTPUT -d sala405-0$i -p tcp -m tcp -j DROP

 else
  iptables -A INPUT -s sala405-$i -p tcp -m tcp -j DROP
  iptables -A INPUT -d sala405-$i -p tcp -m tcp -j DROP
  iptables -A FORWARD -s sala405-$i -p tcp -m tcp -j DROP
  iptables -A FORWARD -d sala405-$i -p tcp -m tcp -j DROP
  iptables -A OUTPUT -s sala405-$i -p tcp -m tcp -j DROP
  iptables -A OUTPUT -d sala405-$i -p tcp -m tcp -j DROP
fi
done
 