#!/bin/bash

#################################################
#  APLICANDO REGRA BLOQUEAR NO LABORATÓRIO 214B  #
#################################################

block=`/etc/GerenciadorFirewall/block-iptables/laboratorios/lab214B/block_forLaboratorio214B.sh`
status=$?
dialog --title "REGRAS DE BLOQUEIO" --msgbox "\n\nLABORATÓRIO 214B BLOQUEADO MENOS O PC DO PROFESSOR" 10 35

case $status in 
0)
clear
exit;;
esac
