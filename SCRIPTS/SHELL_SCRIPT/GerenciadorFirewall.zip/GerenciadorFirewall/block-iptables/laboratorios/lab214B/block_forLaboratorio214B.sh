#!/bin/bash

##########################################################
#  CRIA REGRA IPTABLES PARA BLOQUEAR NO LABORATÓRIO 214B  #
##########################################################

for((i = 2; i <= 21; i++))
do
if [ $i -le 9 ]
 then  
  iptables -A INPUT -s sala214B-0$i -p tcp -m tcp -j DROP
  iptables -A INPUT -d sala214B-0$i -p tcp -m tcp -j DROP
  iptables -A FORWARD -s sala214B-0$i -p tcp -m tcp -j DROP
  iptables -A FORWARD -d sala214B-0$i -p tcp -m tcp -j DROP
  iptables -A OUTPUT -s sala214B-0$i -p tcp -m tcp -j DROP
  iptables -A OUTPUT -d sala214B-0$i -p tcp -m tcp -j DROP

 else
  iptables -A INPUT -s sala214B-$i -p tcp -m tcp -j DROP
  iptables -A INPUT -d sala214B-$i -p tcp -m tcp -j DROP
  iptables -A FORWARD -s sala214B-$i -p tcp -m tcp -j DROP
  iptables -A FORWARD -d sala214B-$i -p tcp -m tcp -j DROP
  iptables -A OUTPUT -s sala214B-$i -p tcp -m tcp -j DROP
  iptables -A OUTPUT -d sala214B-$i -p tcp -m tcp -j DROP
fi
done
