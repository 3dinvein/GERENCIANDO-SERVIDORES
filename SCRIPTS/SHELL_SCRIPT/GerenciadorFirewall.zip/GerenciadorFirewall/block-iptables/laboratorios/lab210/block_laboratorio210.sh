#!/bin/bash

#################################################
#  APLICANDO REGRA BLOQUEAR NO LABORATÓRIO 210  #
#################################################

block=`/etc/GerenciadorFirewall/block-iptables/laboratorios/lab210/block_forLaboratorio210.sh`
status=$?
dialog --title "REGRAS DE BLOQUEIO" --msgbox "\n\nLABORATÓRIO 210 BLOQUEADO MENOS O PC DO PROFESSOR" 10 35

case $status in 
0)
clear
exit;;
esac
