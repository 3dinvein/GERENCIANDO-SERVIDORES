#!/bin/bash

##########################################################
#  CRIA REGRA IPTABLES PARA LIBERAR NO LABORATÓRIO 405  #
##########################################################

for((i = 1; i <= 30; i++))
do
if [ $i -le 9 ]
 then  
  iptables -A INPUT -s sala405-0$i -p tcp -m tcp -j ACCEPT
  iptables -A INPUT -d sala405-0$i -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -s sala405-0$i -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -d sala405-0$i -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -s sala405-0$i -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -d sala405-0$i -p tcp -m tcp -j ACCEPT

 else
  iptables -A INPUT -s sala405-$i -p tcp -m tcp -j ACCEPT
  iptables -A INPUT -d sala405-$i -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -s sala405-$i -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -d sala405-$i -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -s sala405-$i -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -d sala405-$i -p tcp -m tcp -j ACCEPT
fi
done
 