#!/bin/bash

################################################
#  APLICANDO REGRA LIBERAR NO LABORATÓRIO 405  #
################################################

free=`/etc/GerenciadorFirewall/free-iptables/laboratorios/lab405/free_forLaboratorio405.sh`
status=$?
dialog --title "REGRAS DE LIBERAçÃO" --msgbox "\n\nLABORATÓRIO 405 LIBERADO" 10 35

case $status in 
0)
clear
exit;;
esac
