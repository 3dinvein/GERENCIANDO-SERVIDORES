#!/bin/bash

################################################
#  APLICANDO REGRA LIBERAR NO LABORATÓRIO 210  #
################################################

free=`/etc/GerenciadorFirewall/free-iptables/laboratorios/lab210/free_forLaboratorio210.sh`
status=$?
dialog --title "REGRAS DE LIBERAçÃO" --msgbox "\n\nLABORATÓRIO 210 LIBERADO" 10 35

case $status in 
0)
clear
exit;;
esac
