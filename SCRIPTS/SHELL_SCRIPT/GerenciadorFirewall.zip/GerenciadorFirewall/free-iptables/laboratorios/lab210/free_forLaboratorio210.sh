#!/bin/bash

#########################################################
#  CRIA REGRA IPTABLES PARA LIBERAR NO LABORATÓRIO 210  #
#########################################################

for((i = 1; i <= 27; i++))
do
if [ $i -le 9 ]
 then  
  iptables -A INPUT -s sala210-0$i -p tcp -m tcp -j ACCEPT
  iptables -A INPUT -d sala210-0$i -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -s sala210-0$i -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -d sala210-0$i -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -s sala210-0$i -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -d sala210-0$i -p tcp -m tcp -j ACCEPT

 else
  iptables -A INPUT -s sala210-$i -p tcp -m tcp -j ACCEPT
  iptables -A INPUT -d sala210-$i -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -s sala210-$i -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -d sala210-$i -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -s sala210-$i -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -d sala210-$i -p tcp -m tcp -j ACCEPT
fi
done
 
for((i = 29; i <= 37; i++))
do
  iptables -A INPUT -s sala210-$i -p tcp -m tcp -j ACCEPT
  iptables -A INPUT -d sala210-$i -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -s sala210-$i -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -d sala210-$i -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -s sala210-$i -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -d sala210-$i -p tcp -m tcp -j ACCEPT
done 
