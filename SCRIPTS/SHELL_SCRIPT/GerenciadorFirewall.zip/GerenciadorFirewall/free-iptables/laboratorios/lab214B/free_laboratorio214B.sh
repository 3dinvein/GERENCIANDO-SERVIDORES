#!/bin/bash

################################################
#  APLICANDO REGRA LIBERAR NO LABORATÓRIO 214B  #
################################################

free=`/etc/GerenciadorFirewall/free-iptables/laboratorios/lab214B/free_forLaboratorio214B.sh`
status=$?
dialog --title "REGRAS DE LIBERAçÃO" --msgbox "\n\nLABORATÓRIO 214B LIBERADO" 10 35

case $status in 
0)
clear
exit;;
esac
