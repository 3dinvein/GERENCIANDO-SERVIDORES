#!/bin/bash

###########################################################
#  CRIA REGRA IPTABLES PARA LIBERAR NO SALA DE AULA 124  #
###########################################################


  iptables -A INPUT -s sala124-01 -p tcp -m tcp -j ACCEPT
  iptables -A INPUT -d sala124-01 -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -s sala124-01 -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -d sala124-01 -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -s sala124-01 -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -d sala124-01 -p tcp -m tcp -j ACCEPT
