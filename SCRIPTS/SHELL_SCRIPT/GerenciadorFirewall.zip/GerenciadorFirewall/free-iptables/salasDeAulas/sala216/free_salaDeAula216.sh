#!/bin/bash

#################################################
#  APLICANDO REGRA LIBERAR NA SALA DE AULA 216  #
#################################################

free=`/etc/GerenciadorFirewall/free-iptables/salasDeAulas/sala216/free_forSalaDeAula216.sh`
status=$?
dialog --title "REGRAS DE LIBERAçÃO" --msgbox "\n\nSALA DE AULA 216 LIBERADA" 10 35
case $status in 
0)
clear
exit;;
esac
