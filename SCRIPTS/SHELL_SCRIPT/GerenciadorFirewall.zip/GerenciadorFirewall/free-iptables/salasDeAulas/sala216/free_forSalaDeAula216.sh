#!/bin/bash

###########################################################
#  CRIA REGRA IPTABLES PARA LIBERAR NO SALA DE AULA 216  #
###########################################################


  iptables -A INPUT -s sala216-01 -p tcp -m tcp -j ACCEPT
  iptables -A INPUT -d sala216-01 -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -s sala216-01 -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -d sala216-01 -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -s sala216-01 -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -d sala216-01 -p tcp -m tcp -j ACCEPT
