#!/bin/bash

###########################################################
#  CRIA REGRA IPTABLES PARA LIBERAR NO SALA DE AULA 308  #
###########################################################


  iptables -A INPUT -s sala308-01 -p tcp -m tcp -j ACCEPT
  iptables -A INPUT -d sala308-01 -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -s sala308-01 -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -d sala308-01 -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -s sala308-01 -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -d sala308-01 -p tcp -m tcp -j ACCEPT
