#!/bin/bash

##################################################
#  APLICANDO REGRA LIBERAR NA SALA DE AULA 314A  #
##################################################

free=`/etc/GerenciadorFirewall/free-iptables/salasDeAulas/sala314A/free_forSalaDeAula314A.sh`
status=$?
dialog --title "REGRAS DE LIBERAçÃO" --msgbox "\n\nSALA DE AULA 314A LIBERADA" 10 35
case $status in 
0)
clear
exit;;
esac
