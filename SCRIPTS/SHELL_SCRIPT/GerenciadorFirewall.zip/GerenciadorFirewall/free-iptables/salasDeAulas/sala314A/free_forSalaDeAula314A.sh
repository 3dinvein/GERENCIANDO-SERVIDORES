#!/bin/bash

###########################################################
#  CRIA REGRA IPTABLES PARA LIBERAR NO SALA DE AULA 314A  #
###########################################################


  iptables -A INPUT -s sala314A-01 -p tcp -m tcp -j ACCEPT
  iptables -A INPUT -d sala314A-01 -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -s sala314A-01 -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -d sala314A-01 -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -s sala314A-01 -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -d sala314A-01 -p tcp -m tcp -j ACCEPT
