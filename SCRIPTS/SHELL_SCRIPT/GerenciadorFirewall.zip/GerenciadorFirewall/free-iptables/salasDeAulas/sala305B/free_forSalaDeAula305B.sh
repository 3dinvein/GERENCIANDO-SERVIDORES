#!/bin/bash

###########################################################
#  CRIA REGRA IPTABLES PARA LIBERAR NO SALA DE AULA 305B  #
###########################################################


  iptables -A INPUT -s sala305B-01 -p tcp -m tcp -j ACCEPT
  iptables -A INPUT -d sala305B-01 -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -s sala305B-01 -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -d sala305B-01 -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -s sala305B-01 -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -d sala305B-01 -p tcp -m tcp -j ACCEPT
