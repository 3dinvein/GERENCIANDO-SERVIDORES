#!/bin/bash

###########################################################
#  CRIA REGRA IPTABLES PARA LIBERAR NO SALA DE AULA 305A  #
###########################################################


  iptables -A INPUT -s sala305A-01 -p tcp -m tcp -j ACCEPT
  iptables -A INPUT -d sala305A-01 -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -s sala305A-01 -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -d sala305A-01 -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -s sala305A-01 -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -d sala305A-01 -p tcp -m tcp -j ACCEPT
