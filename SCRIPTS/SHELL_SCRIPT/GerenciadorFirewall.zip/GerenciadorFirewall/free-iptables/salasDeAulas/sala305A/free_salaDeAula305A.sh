#!/bin/bash

##################################################
#  APLICANDO REGRA LIBERAR NA SALA DE AULA 305A  #
##################################################

free=`/etc/GerenciadorFirewall/free-iptables/salasDeAulas/sala305A/free_forSalaDeAula305A.sh`
status=$?
dialog --title "REGRAS DE LIBERAçÃO" --msgbox "\n\nSALA DE AULA 305A LIBERADA" 10 35
case $status in 
0)
clear
exit;;
esac
