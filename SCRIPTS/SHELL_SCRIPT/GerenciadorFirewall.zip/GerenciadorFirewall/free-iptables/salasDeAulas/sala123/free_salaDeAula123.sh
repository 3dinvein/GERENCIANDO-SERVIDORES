#!/bin/bash

#################################################
#  APLICANDO REGRA LIBERAR NA SALA DE AULA 123  #
#################################################

free=`/etc/GerenciadorFirewall/free-iptables/salasDeAulas/sala123/free_forSalaDeAula123.sh`
status=$?
dialog --title "REGRAS DE LIBERAçÃO" --msgbox "\n\nSALA DE AULA 123 LIBERADA" 10 35
case $status in 
0)
clear
exit;;
esac
