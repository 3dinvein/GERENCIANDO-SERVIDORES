#!/bin/bash

##################################################
#  APLICANDO REGRA LIBERAR NA SALA DE AULA 314B  #
##################################################

free=`/etc/GerenciadorFirewall/free-iptables/salasDeAulas/sala314B/free_forSalaDeAula314B.sh`
status=$?
dialog --title "REGRAS DE LIBERAçÃO" --msgbox "\n\nSALA DE AULA 314B LIBERADA" 10 35
case $status in 
0)
clear
exit;;
esac
