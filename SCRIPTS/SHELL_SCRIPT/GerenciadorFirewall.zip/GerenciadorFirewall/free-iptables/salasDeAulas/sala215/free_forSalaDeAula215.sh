#!/bin/bash

###########################################################
#  CRIA REGRA IPTABLES PARA LIBERAR NO SALA DE AULA 215A  #
###########################################################


  iptables -A INPUT -s sala215A-01 -p tcp -m tcp -j ACCEPT
  iptables -A INPUT -d sala215A-01 -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -s sala215A-01 -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -d sala215A-01 -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -s sala215A-01 -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -d sala215A-01 -p tcp -m tcp -j ACCEPT
