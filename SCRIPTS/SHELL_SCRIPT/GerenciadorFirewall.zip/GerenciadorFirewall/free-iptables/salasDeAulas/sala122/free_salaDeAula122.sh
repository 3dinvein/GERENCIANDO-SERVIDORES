#!/bin/bash

#################################################
#  APLICANDO REGRA LIBERAR NA SALA DE AULA 122  #
#################################################

free=`/etc/GerenciadorFirewall/free-iptables/salasDeAulas/sala122/free_forSalaDeAula122.sh`
status=$?
dialog --title "REGRAS DE LIBERAçÃO" --msgbox "\n\nSALA DE AULA 122 LIBERADA" 10 35
case $status in 
0)
clear
exit;;
esac
