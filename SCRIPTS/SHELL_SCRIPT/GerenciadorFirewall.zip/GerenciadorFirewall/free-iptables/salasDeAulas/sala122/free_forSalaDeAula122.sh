#!/bin/bash

###########################################################
#  CRIA REGRA IPTABLES PARA LIBERAR NO SALA DE AULA 122  #
###########################################################


  iptables -A INPUT -s sala122-01 -p tcp -m tcp -j ACCEPT
  iptables -A INPUT -d sala122-01 -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -s sala122-01 -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -d sala122-01 -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -s sala122-01 -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -d sala122-01 -p tcp -m tcp -j ACCEPT
