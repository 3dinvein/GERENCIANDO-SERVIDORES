#!/bin/bash

#################################################
#  APLICANDO REGRA LIBERAR NO AUDITÓRIO 409     #
#################################################

free=`/etc/GerenciadorFirewall/free-iptables/auditorios/auditorio409/free_forAuditorio409.sh`
status=$?
dialog --title "REGRAS DE LIBERAçÃO" --msgbox "\n\nAUDITÓRIO 409 LIBERADO" 10 35
case $status in 
0)
clear
exit;;
esac
