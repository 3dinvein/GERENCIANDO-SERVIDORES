#!/bin/bash

##########################################################
#  CRIA REGRA IPTABLES PARA LIBERAR NO AUDITÓRIO 409    #
##########################################################
 
  iptables -A INPUT -s sala409-01 -p tcp -m tcp -j ACCEPT
  iptables -A INPUT -d sala409-01 -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -s sala409-01 -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -d sala409-01 -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -s sala409-01 -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -d sala409-01 -p tcp -m tcp -j ACCEPT
