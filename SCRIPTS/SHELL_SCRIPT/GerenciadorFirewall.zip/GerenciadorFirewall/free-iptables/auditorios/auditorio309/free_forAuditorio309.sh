#!/bin/bash

##########################################################
#  CRIA REGRA IPTABLES PARA LIBERAR NO AUDITÓRIO 309    #
##########################################################
 
  iptables -A INPUT -s auditorio -p tcp -m tcp -j ACCEPT
  iptables -A INPUT -d auditorio -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -s auditorio -p tcp -m tcp -j ACCEPT
  iptables -A FORWARD -d auditorio -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -s auditorio -p tcp -m tcp -j ACCEPT
  iptables -A OUTPUT -d auditorio -p tcp -m tcp -j ACCEPT
