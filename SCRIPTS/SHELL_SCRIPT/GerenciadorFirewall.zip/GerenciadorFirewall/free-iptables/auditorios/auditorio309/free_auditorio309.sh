#!/bin/bash

#################################################
#  APLICANDO REGRA LIBERAR NO AUDITÓRIO 309     #
#################################################

free=`/etc/GerenciadorFirewall/free-iptables/auditorios/auditorio309/free_forAuditorio309.sh`
status=$?
dialog --title "REGRAS DE LIBERAçÃO" --msgbox "\n\nAUDITÓRIO 309 LIBERADO" 10 35
case $status in 
0)
clear
exit;;
esac
