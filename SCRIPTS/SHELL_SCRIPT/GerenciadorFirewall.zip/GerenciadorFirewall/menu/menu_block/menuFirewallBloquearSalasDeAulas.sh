#!/bin/bash

############################################################## 
#  MENU DO GERENCIADOR DE FIREWALL - APLICAR REGRA BLOQUEAR  #
##############################################################

menu=$(dialog --menu "ESCOLHA QUAL SALA DE AULA VOCÊ DESEJA APLICAR A REGRA:" 30 60 14 1 "SALA 122" 2 "SALA 123" 3 "SALA 124" 4 "SALA 215" 5 "SALA 216" 6 "SALA 305A" 7 "SALA 305B" 8 "SALA 308" 9 "SALA 314A" 10 "SALA 314B" 11 "SALA 316" 12 "VOLTAR" 13 "SAIR DO GERENCIADOR" --stdout)

status=$?

case $menu in 
1)
/etc/GerenciadorFirewall/block-iptables/salasDeAulas/sala122/block_salaDeAula122.sh;;
2)
/etc/GerenciadorFirewall/block-iptables/salasDeAulas/sala123/block_salaDeAula123.sh;;
3)
/etc/GerenciadorFirewall/block-iptables/salasDeAulas/sala124/block_salaDeAula124.sh;;
4)
/etc/GerenciadorFirewall/block-iptables/salasDeAulas/sala215/block_salaDeAula215.sh;;
5)
/etc/GerenciadorFirewall/block-iptables/salasDeAulas/sala216/block_salaDeAula216.sh;;
6)
/etc/GerenciadorFirewall/block-iptables/salasDeAulas/sala305A/block_salaDeAula305A.sh;;
7)
/etc/GerenciadorFirewall/block-iptables/salasDeAulas/sala305B/block_salaDeAula305B.sh;;
8)
/etc/GerenciadorFirewall/block-iptables/salasDeAulas/sala308/block_salaDeAula308.sh;;
9)
/etc/GerenciadorFirewall/block-iptables/salasDeAulas/sala314A/block_salaDeAula314A.sh;;
10)
/etc/GerenciadorFirewall/block-iptables/salasDeAulas/sala314B/block_salaDeAula314B.sh;;
11)
/etc/GerenciadorFirewall/block-iptables/salasDeAulas/sala316/block_salaDeAula316.sh;;
12)
/etc/GerenciadorFirewall/menu/menuFirewallBloquear.sh;;
13)
clear
exit;;
esac

case $status in
1)
clear
exit;;
esac
