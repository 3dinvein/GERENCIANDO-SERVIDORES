#!/bin/bash

############################################################## 
#  MENU DO GERENCIADOR DE FIREWALL - APLICAR REGRA BLOQUEAR  #
##############################################################

menu=$(dialog --menu "ESCOLHA QUAL AUDITÓRIO VOCÊ DESEJA APLICAR A REGRA:" 30 60 5 1 "AUDITÓRIO 309" 2 "AUDITÓRIO 409" 3 "VOLTAR" 4 "SAIR DO GERENCIADOR" --stdout)

status=$?

case $menu in 
1)
/etc/GerenciadorFirewall/block-iptables/auditorios/auditorio309/block_auditorio309.sh;;
2)
/etc/GerenciadorFirewall/block-iptables/auditorios/auditorio409/block_auditorio409.sh;;
3)
/etc/GerenciadorFirewall/menu/menuFirewallBloquear.sh;;
4)
clear
exit;;
esac

case $status in
1)
clear
exit;;
esac
