#!/bin/bash

############################################################## 
#  MENU DO GERENCIADOR DE FIREWALL - APLICAR REGRA BLOQUEAR  #
##############################################################

menu=$(dialog --menu "ESCOLHA QUAL LABORATÓRIO VOCÊ DESEJA APLICAR A REGRA:" 30 60 6 1 "LABORATÓRIO 210" 2 "LABORARATÓRIO 214B" 3 "LABORATÓRIO 405" 4 "VOLTAR" 5 "SAIR DO GERENCIADOR" --stdout)

status=$?

case $menu in 
1)
/etc/GerenciadorFirewall/block-iptables/laboratorios/lab210/block_laboratorio210.sh;;
2)
/etc/GerenciadorFirewall/block-iptables/laboratorios/lab214B/block_laboratorio214B.sh;;
3)
/etc/GerenciadorFirewall/block-iptables/laboratorios/lab405/block_laboratorio405.sh;;
4)
/etc/GerenciadorFirewall/menu/menuFirewallBloquear.sh;;
5)
clear
exit;;
esac

case $status in
1)
clear
exit;;
esac
