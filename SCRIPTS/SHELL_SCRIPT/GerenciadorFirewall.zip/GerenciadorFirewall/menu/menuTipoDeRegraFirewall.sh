#!/bin/bash  

#########################################################
#   MENU DO GERENCIADOR DE FIREWALL - TIPO DE REGRA     #
#########################################################

menu=$(dialog --menu "ESCOLHA O TIPO DE REGRA:\n" 20 35 5 1 "BLOQUEAR" 2 "LIBERAR" 3 "VOLTAR" 4 "SAIR DO GERENCIADOR" --stdout)

status=$?

if [ $menu -eq 1 ];
 then
   /etc/GerenciadorFirewall/menu/menuFirewallBloquear.sh
elif [ $menu -eq 2 ];
 then
  /etc/GerenciadorFirewall/menu/menuFirewallLiberar.sh
elif [ $menu -eq 3 ];
 then
   gerenciadorFirewall.sh
elif [ $menu -eq 4 ];
 then
  clear
  exit 
fi

case $status in
1)
clear;
exit;;
*)
clear
exit;;
esac
