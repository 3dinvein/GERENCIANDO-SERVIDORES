#!/bin/bash

#########################################################
#       MENU DO GERENCIADOR DE FIREWALL - BLOQUEAR      #
#########################################################

menu=$(dialog --menu "ESCOLHA O QUE VOCÊ QUER BLOQUEAR?\n\n" 20 40 6 1 "LABORATÓRIOS" 2 "SALAS DE AULAS" 3 "AUDITÓRIOS" 4 "VOLTAR" 5 "SAIR DO GERENCIADOR" --stdout)

status=$?

case $menu in 
1)
#echo "LABORATÓRIOS";
/etc/GerenciadorFirewall/menu/menu_block/menuFirewallBloquearLaboratorio.sh;;
2)
#echo "SALAS DE AULAS";
/etc/GerenciadorFirewall/menu/menu_block/menuFirewallBloquearSalasDeAulas.sh;;
3)
#echo "AUDITÓRIOS";
/etc/GerenciadorFirewall/menu/menu_block/menuFirewallBloquearAuditorios.sh;;
4)
/etc/GerenciadorFirewall/menu/menuTipoDeRegraFirewall.sh;;
5)
clear
exit;;
esac

case $status in
1)
clear
exit;;
esac
