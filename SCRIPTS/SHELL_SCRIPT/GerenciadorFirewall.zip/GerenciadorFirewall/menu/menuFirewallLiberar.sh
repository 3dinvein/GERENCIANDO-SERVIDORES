#!/bin/bash

#########################################################
#       MENU DO GERENCIADOR DE FIREWALL - LIBERAR       #
#########################################################

menu=$(dialog --menu "ESCOLHA O QUE VOCÊ QUER LIBERAR?\n\n" 20 40 6 1 "LABORATÓRIOS" 2 "SALAS DE AULAS" 3 "AUDITÓRIOS" 4 "VOLTAR" 5 "SAIR DO GERENCIADOR" --stdout)

status=$?

case $menu in 
1)
/etc/GerenciadorFirewall/menu/menu_free/menuFirewallLiberarLaboratorio.sh;;
2)
/etc/GerenciadorFirewall/menu/menu_free/menuFirewallLiberarSalaDeAulas.sh;;
3)
/etc/GerenciadorFirewall/menu/menu_free/menuFirewallLiberarAuditorios.sh;;
4)
/etc/GerenciadorFirewall/menu/menuTipoDeRegraFirewall.sh;;
5)
clear
exit;;
esac

case $status in
1)
clear
exit;;
esac
