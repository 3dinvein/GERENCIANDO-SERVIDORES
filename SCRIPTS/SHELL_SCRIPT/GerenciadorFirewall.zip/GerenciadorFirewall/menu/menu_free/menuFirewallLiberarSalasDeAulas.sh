#!/bin/bash

############################################################## 
#  MENU DO GERENCIADOR DE FIREWALL - APLICAR REGRA  LIBERAR  #
##############################################################

menu=$(dialog --menu "ESCOLHA QUAL SALA DE AULA VOCÊ DESEJA APLICAR A REGRA:" 30 60 14 1 "SALA 122" 2 "SALA 123" 3 "SALA 124" 4 "SALA 215" 5 "SALA 216" 6 "SALA 305A" 7 "SALA 305B" 8 "SALA 308" 9 "SALA 314A" 10 "SALA 314B" 11 "SALA 316" 12 "VOLTAR" 13 "SAIR DO GERENCIADOR" --stdout)

status=$?

case $menu in 
1)
/etc/GerenciadorFirewall/free-iptables/salasDeAulas/sala122/free_salaDeAula122.sh;;
2)
/etc/GerenciadorFirewall/free-iptables/salasDeAulas/sala123/free_salaDeAula123.sh;;
3)
/etc/GerenciadorFirewall/free-iptables/salasDeAulas/sala124/free_salaDeAula124.sh;;
4)
/etc/GerenciadorFirewall/free-iptables/salasDeAulas/sala215/free_salaDeAula215.sh;;
5)
/etc/GerenciadorFirewall/free-iptables/salasDeAulas/sala216/free_salaDeAula216.sh;;
6)
/etc/GerenciadorFirewall/free-iptables/salasDeAulas/sala305A/free_salaDeAula305A.sh;;
7)
/etc/GerenciadorFirewall/free-iptables/salasDeAulas/sala305B/free_salaDeAula305B.sh;;
8)
/etc/GerenciadorFirewall/free-iptables/salasDeAulas/sala308/free_salaDeAula308.sh;;
9)
/etc/GerenciadorFirewall/free-iptables/salasDeAulas/sala314A/free_salaDeAula314A.sh;;
10)
/etc/GerenciadorFirewall/free-iptables/salasDeAulas/sala314B/free_salaDeAula314B.sh;;
11)
/etc/GerenciadorFirewall/free-iptables/salasDeAulas/sala316/free_salaDeAula316.sh;;
12)
/etc/GerenciadorFirewall/menu/menuFirewallLiberar.sh;;
13)
clear
exit;;
esac

case $status in
1)
clear
exit;;
esac
